






require('dotenv').config();
const qrcode = require('qrcode-terminal');
const fs = require('fs');
const path = require('path');
const yts = require('yt-search');              
const ytdl = require('ytdl-core');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, downloadContentFromMessage } = require('@whiskeysockets/baileys');

// ✅ TEXT-TO-SPEECH FUNCTION ADD KARO
const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);

async function createVoiceFile(text, filename) {
    try {
        const voicePath = path.join(BOT_BASE_PATH, 'voices', filename);
        
        // Windows ke liye PowerShell text-to-speech
        const command = `powershell -Command "Add-Type -AssemblyName System.speech; $speak = New-Object System.Speech.Synthesis.SpeechSynthesizer; $speak.SetOutputToWaveFile('${voicePath}'); $speak.Speak('${text}'); $speak.Dispose()"`;
        
        await execAsync(command);
        console.log(`✅ Voice file created: ${filename}`);
        return true;
    } catch (error) {
        console.error(`❌ Voice creation failed: ${error}`);
        return false;
    }
}

// ✅ SIRF HI VOICE FILE CREATE KARNE KA FUNCTION
async function createHiVoiceFile() {
    const voiceDir = path.join(BOT_BASE_PATH, 'voices');
    
    if (!fs.existsSync(voiceDir)) {
        fs.mkdirSync(voiceDir, { recursive: true });
    }
    
    const voiceFile = 'hi_voice.mp3';
    const filePath = path.join(voiceDir, voiceFile);
    
    console.log(`🎵 Creating hi voice file: ${filePath}`);
    
    if (!fs.existsSync(filePath)) {
        const success = await createVoiceFile("Hello my friend", voiceFile);
        if (success) {
            console.log(`✅ Hi voice file created successfully: ${voiceFile}`);
        } else {
            console.log(`❌ Failed to create hi voice file`);
            // Fallback - create empty file
            fs.writeFileSync(filePath, 'VOICE_PLACEHOLDER');
        }
    } else {
        console.log(`✅ Hi voice file already exists: ${voiceFile}`);
    }
}

// ✅ CREATE READLINE INTERFACE FOR USER INPUT
const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// ✅ YOUR EXACT FOLDER STRUCTURE SETUP
console.log('🔧 Setting up D: Drive for all operations...');
const BOT_BASE_PATH = 'D:\\MyBot\\WhatsAppBot';

// Set environment variables to your exact paths
process.env.TMP = path.join(BOT_BASE_PATH, 'temp');
process.env.TEMP = path.join(BOT_BASE_PATH, 'temp');
process.env.TMPDIR = path.join(BOT_BASE_PATH, 'temp');
process.env.HOME = BOT_BASE_PATH;
process.env.USERPROFILE = BOT_BASE_PATH;

// Create necessary folders in your exact structure
const folders = [
    path.join(BOT_BASE_PATH, 'temp'),
    path.join(BOT_BASE_PATH, 'cache'), 
    path.join(BOT_BASE_PATH, 'media'),
    path.join(BOT_BASE_PATH, 'downloads'),
    path.join(BOT_BASE_PATH, 'voices'),
    path.join(BOT_BASE_PATH, 'session')
];

folders.forEach(folder => {
    if (!fs.existsSync(folder)) {
        fs.mkdirSync(folder, { recursive: true });
        console.log(`✅ Created folder: ${folder}`);
    }
});

console.log('🎯 D: Drive Setup Completed:');
console.log('📁 Bot Path: ' + BOT_BASE_PATH);
console.log('🎵 Voices Path: ' + path.join(BOT_BASE_PATH, 'voices'));

// ✅ BOT CONFIGURATION
const BOT_CONFIG = {
    name: process.env.BOT_NAME || '🔥 NIL BOT',
    prefix: process.env.PREFIX || '.',
    owner: process.env.OWNER || '923474810818',
    ownerNumbers: ['923474810818', '923474810818@s.whatsapp.net'],
    botNumber: '923471931926',
    ownerName: 'NIL',
    mode: 'public',
    features: {
        welcomeMessage: true,
        goodbyeMessage: true, 
        youtubeLinks: true,
        nsfwBlock: true 
    }
};

// ✅ BOT DATA STORAGE
let botData = {
    commandsUsed: 0,
    startTime: Date.now(),
    isConnected: false,
    sudos: [],
    groupSettings: new Map(),
    antiLinkGroups: new Set(),
    fightMode: new Map(),
    ongoingFights: new Map(),
    userWarns: new Map(),
    deploymentMethod: null,
    fightUsers: new Map(),
    voiceMode: new Set(),
    currentFightIndex: new Map()
};

// ✅ UPDATED VOICE MESSAGE SENDER FUNCTION - SIRF HI VOICE KE LIYE
async function sendVoiceMessage(sock, jid, voiceFile, quotedMsg = null) {
    try {
        const voicePath = path.join(BOT_BASE_PATH, 'voices', voiceFile);
        
        console.log(`🎵 Looking for voice file: ${voicePath}`);
        
        if (!fs.existsSync(voicePath)) {
            console.log(`❌ Voice file not found: ${voicePath}`);
            
            // Sirf hi voice file create karo
            await createHiVoiceFile();
            
            // Check again after creation
            if (!fs.existsSync(voicePath)) {
                await sock.sendMessage(jid, { 
                    text: `🎵 *Voice Mode*\n\n✅ Voice response triggered!\n📁 File: ${voiceFile}\n\n⚠️ Voice file setup complete!`
                }, { quoted: quotedMsg });
                return;
            }
        }

        const stats = fs.statSync(voicePath);
        console.log(`📊 Voice file stats: ${stats.size} bytes`);

        // ✅ PROPER WAY TO SEND VOICE MESSAGE
        await sock.sendMessage(jid, {
            audio: fs.readFileSync(voicePath),
            mimetype: 'audio/mpeg',
            ptt: true, // Push-to-talk
            fileName: voiceFile
        }, {
            quoted: quotedMsg
        });

        console.log(`✅ Voice sent successfully: ${voiceFile}`);
        
    } catch (error) {
        console.error('Voice message error:', error);
        // Fallback to text
        await sock.sendMessage(jid, { 
            text: `🎵 *Voice: HI*\n\n✅ Voice response triggered!\n\n🔊 Audio file sent successfully!`
        }, { quoted: quotedMsg });
    }
}

// ✅ DEPLOYMENT METHOD SELECTOR
function selectDeploymentMethod() {
    console.log('\n' + '='.repeat(60));
    console.log('🚀 NIL BOT - DEPLOYMENT METHODS');
    console.log('='.repeat(60));
    console.log('1️⃣  QR CODE SCAN (Recommended)');
    console.log('2️⃣  PHONE NUMBER (Direct Login)');
    console.log('='.repeat(60));
    
    rl.question('👉 Select option (1 or 2): ', (answer) => {
        if (answer === '1') {
            botData.deploymentMethod = 'qr';
            console.log('\n✅ Selected: QR CODE DEPLOYMENT');
            startBotWithQR();
        } else if (answer === '2') {
            botData.deploymentMethod = 'phone';
            console.log('\n✅ Selected: PHONE NUMBER DEPLOYMENT');
            startBotWithPhone();
        } else {
            console.log('\n❌ Invalid option! Please select 1 or 2');
            selectDeploymentMethod();
        }
    });
}

// ✅ PHONE NUMBER DEPLOYMENT
function startBotWithPhone() {
    console.log('\n' + '='.repeat(50));
    console.log('📱 PHONE NUMBER DEPLOYMENT');
    console.log('='.repeat(50));
    
    rl.question('👉 Enter your WhatsApp number (with country code): ', (phoneNumber) => {
        phoneNumber = phoneNumber.trim().replace(/[^0-9+]/g, '');
        
        if (!phoneNumber.startsWith('+')) {
            phoneNumber = '+' + phoneNumber;
        }
        
        if (phoneNumber.length < 10) {
            console.log('❌ Invalid phone number! Please try again.');
            startBotWithPhone();
            return;
        }
        
        console.log(`\n✅ Phone Number: ${phoneNumber}`);
        console.log('🔄 Starting phone authentication...');
        
        startBot();
    });
}

// ✅ QR CODE DEPLOYMENT
function startBotWithQR() {
    console.log('\n' + '='.repeat(50));
    console.log('📱 QR CODE DEPLOYMENT');
    console.log('='.repeat(50));
    console.log('1. WhatsApp Open Karein');
    console.log('2. Settings → Linked Devices → Link a Device');
    console.log('3. QR Code Scan Karein');
    console.log('='.repeat(50));
    
    startBot();
}

// ✅ MESSAGE TEXT EXTRACTOR
function getMessageText(message) {
    const msgContent = message.message;
    if (msgContent.conversation) return msgContent.conversation;
    if (msgContent.extendedTextMessage?.text) return msgContent.extendedTextMessage.text;
    if (msgContent.imageMessage?.caption) return msgContent.imageMessage.caption;
    if (msgContent.videoMessage?.caption) return msgContent.videoMessage.caption;
    return '';
}

// ✅ FIGHT RESPONSE FUNCTION
async function handleFightResponseNew(sock, jid, userId) {
    try {
        const userFightData = botData.fightUsers.get(userId);
        if (!userFightData) return;

        const { sentences, lastQuotedMsg } = userFightData;
        const CURRENT_DELAY = 2500;

        for (let i = 0; i < sentences.length; i++) {
            if (userFightData.currentIndex >= sentences.length) {
                userFightData.currentIndex = 0;
            }
            
            const sentence = sentences[userFightData.currentIndex];
            userFightData.currentIndex++;
            
            await sock.sendMessage(jid, { 
                text: sentence
            }, { 
                quoted: lastQuotedMsg
            });
            
            console.log(`🥊 Fight response ${userFightData.currentIndex}/${sentences.length} to ${userId}: ${sentence}`);
            
            if (CURRENT_DELAY > 0) {
                await new Promise(resolve => setTimeout(resolve, CURRENT_DELAY));
            }
        }
        
        console.log(`✅ All fight sentences sent to ${userId}`);

    } catch (error) {
        console.error('Fight response error:', error);
    }
}

// ✅ BOT START MEIN SIRF HI VOICE FILE CREATE KARO
async function startBot() {
    console.log('🚀 Starting Ultimate Nil Bot...');
    console.log('📁 Bot Location: ' + BOT_BASE_PATH);
    
    try {
        const sessionPath = path.join(BOT_BASE_PATH, 'session');
        const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
        const { version } = await fetchLatestBaileysVersion();

        const sock = makeWASocket({
            version,
            auth: state,
            printQRInTerminal: false,
            browser: ['NIL BOT', 'Chrome', '120.0.0.0'],
            markOnlineOnConnect: true,
            syncFullHistory: false,
            connectTimeoutMs: 30000,
            defaultQueryTimeoutMs: 60000,
        });

        sock.ev.on('creds.update', saveCreds);

        // ✅ CONNECTION HANDLER
        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;
            
            console.log('🔗 Connection Status:', connection);
            
            if (qr) {
                console.log('\n' + '='.repeat(50));
                console.log('📱 SCAN QR CODE WITH WHATSAPP');
                console.log('='.repeat(50));
                qrcode.generate(qr, { small: true });
                console.log('\n');
            }
            
            if (connection === 'open') {
                console.log('🎉 BOT CONNECTED!');
                console.log(`📱 Deployment Method: ${botData.deploymentMethod}`);
                botData.isConnected = true;
                
                // ✅ SIRF HI VOICE FILE CREATE KARO
                await createHiVoiceFile();
                
                try {
                    await sock.sendMessage(`${BOT_CONFIG.owner}@s.whatsapp.net`, {
                        text: `✅ *BOT CONNECTED!*\n\n🤖 ${BOT_CONFIG.name}\n📁 Path: ${BOT_BASE_PATH}\n🎵 Voice Mode: Ready\n📅 ${new Date().toLocaleString()}`
                    });
                } catch (e) {
                    console.log('Owner notification failed');
                }
            }
            
            if (connection === 'close') {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                console.log('🔌 Connection closed, Status Code:', statusCode);
                
                if (statusCode === 428) {
                    console.log('🔄 Conflict detected - Cleaning session...');
                    if (fs.existsSync(sessionPath)) {
                        fs.rmSync(sessionPath, { recursive: true });
                        console.log('🗑️ Session cleared');
                    }
                    setTimeout(() => selectDeploymentMethod(), 10000);
                }
                else if (statusCode === 401) {
                    console.log('❌ Unauthorized - Need new login');
                    if (fs.existsSync(sessionPath)) {
                        fs.rmSync(sessionPath, { recursive: true });
                    }
                    setTimeout(() => selectDeploymentMethod(), 5000);
                }
                else {
                    console.log('🔄 Reconnecting in 5 seconds...');
                    setTimeout(() => selectDeploymentMethod(), 5000);
                }
                
                botData.isConnected = false;
            }
        });

        // ✅ MESSAGE HANDLER
        sock.ev.on('messages.upsert', async ({ messages }) => {
            try {
                const msg = messages[0];
                if (!msg.message || msg.key.fromMe) return;
                
                const jid = msg.key.remoteJid;
                const isGroup = jid.endsWith('@g.us');
                const text = getMessageText(msg)?.toLowerCase() || '';
                const isBotMessage = msg.key.fromMe;

                console.log('📨 Message received from:', jid);
                console.log('💬 Text:', text);

                // ✅ VOICE MODE CHECK - SIRF HI COMMAND KE LIYE
                if (botData.voiceMode.has('global') && !isBotMessage && text) {
                    console.log('🎵 Voice mode active, checking commands...');
                    
                    // SIRF HI COMMAND CHECK KARO
                    if (text.includes('hi') || text.includes('hello')) {
                        console.log(`🎵 Voice triggered: hi -> hi_voice.mp3`);
                        await sendVoiceMessage(sock, jid, 'hi_voice.mp3', msg);
                        return;
                    }
                }

                // ✅ FIGHT MODE TRIGGER
                if (botData.fightMode.has('global')) {
                    const fightText = getMessageText(msg).toLowerCase();
                    const userId = msg.key.participant || msg.key.remoteJid;
                    
                    if (!isBotMessage) {
                        const triggerWords = ['randi', 'mc', 'bc', 'chod', 'madarchod', 'bhosdi', 'gaand', 'lund', 'chut', 'kutta', 'kamine', 'harami'];
                        const foundBadWord = triggerWords.some(word => fightText.includes(word));
                        
                        const mentionsBot = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.includes(sock.user.id);
                        
                        if (foundBadWord || mentionsBot) {
                            const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
                            const senderNumber = msg.key.participant || msg.key.remoteJid;
                            
                            if (senderNumber === botNumber || msg.key.remoteJid === botNumber) {
                                console.log(`🚫 Ignoring abuse from bot's own number: ${fightText}`);
                                return;
                            }
                            
                            console.log(`🥊 Fight triggered by ${userId}: ${fightText}`);
                            
                            if (!botData.fightUsers.has(userId)) {
                                botData.fightUsers.set(userId, {
                                    sentences: ["TERI MAA CHODU", "TERI BEHEN RANDI"],
                                    currentIndex: 0,
                                    lastQuotedMsg: msg
                                });
                            } else {
                                botData.fightUsers.get(userId).lastQuotedMsg = msg;
                            }
                            
                            await handleFightResponseNew(sock, jid, userId);
                            return;
                        }
                    }
                }

                // ✅ VOICE MODE COMMANDS
                if (text.startsWith(BOT_CONFIG.prefix)) {
                    const body = text.slice(BOT_CONFIG.prefix.length).trim();
                    const args = body.split(/\s+/);
                    const command = args.shift().toLowerCase();

                    if (command === 'voice') {
                        const action = args[0]?.toLowerCase();
                        
                        if (action === 'on') {
                            botData.voiceMode.add('global');
                            await sock.sendMessage(jid, { 
                                text: `✅ *VOICE MODE ON!*\n\n🎵 Voice responses activated!\n📁 Voice Folder: ${path.join(BOT_BASE_PATH, 'voices')}\n\nNow type "hi" or "hello" to test voice!`
                            }, { quoted: msg });
                            return;
                        }
                        
                        if (action === 'off') {
                            botData.voiceMode.delete('global');
                            await sock.sendMessage(jid, { 
                                text: '❌ *VOICE MODE OFF!*\n\n🔇 Voice responses disabled'
                            }, { quoted: msg });
                            return;
                        }
                        
                        if (action === 'list') {
                            const voiceList = `
🎵 *VOICE MODE COMMANDS*

🔊 *Available Voice Responses:*
• hi / hello - Sends hi_voice.mp3

⚡ *Usage:*
.voice on - Voice mode start
.voice off - Voice mode band
.voice list - Commands list

📁 *Voice Files Location:*
${path.join(BOT_BASE_PATH, 'voices')}
                            `.trim();
                            await sock.sendMessage(jid, { text: voiceList }, { quoted: msg });
                            return;
                        }
                        
                        if (action === 'status') {
                            const status = botData.voiceMode.has('global') ? 'ON 🎵' : 'OFF 🔇';
                            const voiceFiles = fs.existsSync(path.join(BOT_BASE_PATH, 'voices')) ? 
                                fs.readdirSync(path.join(BOT_BASE_PATH, 'voices')) : [];
                            
                            await sock.sendMessage(jid, { 
                                text: `🎵 *VOICE MODE STATUS*\n\n• Status: ${status}\n• Voice Files: ${voiceFiles.length}\n• Path: ${path.join(BOT_BASE_PATH, 'voices')}`
                            }, { quoted: msg });
                            return;
                        }
                        
                        const status = botData.voiceMode.has('global') ? 'ON 🎵' : 'OFF 🔇';
                        await sock.sendMessage(jid, { 
                            text: `🎵 *VOICE MODE*\n\n• Status: ${status}\n• Use: .voice on/off/list/status` 
                        }, { quoted: msg });
                        return;
                    }
                }

                // ✅ COMMAND CHECK
                if (text.startsWith(BOT_CONFIG.prefix)) {
                    await handleCommand(sock, msg);
                }
                
            } catch (error) {
                console.error('Message handling error:', error);
            }
        });

        console.log('🎯 Bot initialized successfully!');
        console.log('🎵 Voice Mode: Ready (Only hi_voice.mp3)');
        console.log('📁 Working Directory: ' + BOT_BASE_PATH);

    } catch (error) {
        console.error('Startup failed:', error.message);
        setTimeout(startBot, 5000);
    }
}

// ✅ GROUP SETTINGS INITIALIZER
function initGroupSettings(jid) {
    if (!botData.groupSettings.has(jid)) {
        botData.groupSettings.set(jid, {
            antiLink: false,
            deleteLink: true,
            kickOnLink: false,
            warnOnLink: true,
            welcome: true,  
            goodbye: true,
            nsfw: true,
            muted: false,
            muteDuration: null
        });
    }
    return botData.groupSettings.get(jid);
}

// ✅ LINK DETECTOR
function isLink(text) {
    const linkRegex = /https?:\/\/[^\s]+|www\.[^\s]+|\.com|\.org|\.net|\.in/gi;
    return linkRegex.test(text);
}

// ✅ ADMIN CHECKER
async function isAdmin(sock, jid, user) {
    try {
        if (!jid.endsWith('@g.us')) return false;
        
        const metadata = await sock.groupMetadata(jid);
        const participants = metadata.participants;
        const userObj = participants.find(p => p.id === user);
        
        return userObj?.admin === 'admin' || userObj?.admin === 'superadmin';
    } catch (error) {
        console.log('Admin check error:', error);
        return false;
    }
}

// ✅ OWNER CHECKER
function isUserOwner(user) {
    const userNormalized = user.replace('@s.whatsapp.net', '').replace('@lid', '').replace(/[^0-9]/g, '');
    const ownerNormalized = BOT_CONFIG.owner.replace(/[^0-9]/g, '');
    
    return userNormalized === ownerNormalized;
}

// ✅ WARN SYSTEM FUNCTIONS
function addUserWarn(jid, userId) {
    const warnKey = `${jid}_${userId}`;
    if (!botData.userWarns.has(warnKey)) {
        botData.userWarns.set(warnKey, 0);
    }
    const currentWarns = botData.userWarns.get(warnKey) + 1;
    botData.userWarns.set(warnKey, currentWarns);
    return currentWarns;
}

function getUserWarns(jid, userId) {
    const warnKey = `${jid}_${userId}`;
    return botData.userWarns.get(warnKey) || 0;
}

function resetUserWarns(jid, userId) {
    const warnKey = `${jid}_${userId}`;
    botData.userWarns.delete(warnKey);
}

async function resetAllWarns(jid) {
    for (let [key, value] of botData.userWarns) {
        if (key.startsWith(jid)) {
            botData.userWarns.delete(key);
        }
    }
}

// ✅ UPTIME FORMATTER
function formatUptime(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

// ✅ MEDIA DOWNLOADER
async function downloadMediaFromMessage(message) {
    try {
        let mediaType;
        let mediaMessage;
        
        if (message.imageMessage) {
            mediaType = 'image';
            mediaMessage = message.imageMessage;
        } else if (message.videoMessage) {
            mediaType = 'video';
            mediaMessage = message.videoMessage;
        } else if (message.stickerMessage) {
            mediaType = 'sticker';
            mediaMessage = message.stickerMessage;
        } else {
            throw new Error('Unsupported media type');
        }

        const stream = await downloadContentFromMessage(mediaMessage, mediaType);
        return stream;
    } catch (error) {
        throw new Error(`Download failed: ${error.message}`);
    }
}

function streamToBuffer(stream) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        stream.on('data', (chunk) => chunks.push(chunk));
        stream.on('end', () => resolve(Buffer.concat(chunks)));
        stream.on('error', reject);
    });
}

// ✅ COMMAND HANDLER
async function handleCommand(sock, msg) {
    const jid = msg.key.remoteJid;
    const user = msg.key.participant || jid;
    const text = getMessageText(msg);
    const body = text.slice(BOT_CONFIG.prefix.length).trim();
    const args = body.split(/\s+/);
    const command = args.shift().toLowerCase();
    const fullArgs = args.join(' ');

    console.log(`📨 Command: ${command} from ${jid}`);
    botData.commandsUsed++;

    const actualIsOwner = isUserOwner(user);
    const actualIsSudo = botData.sudos.some(sudo => isUserOwner(sudo));
    const actualIsAuthorized = BOT_CONFIG.mode === 'public' || actualIsOwner || actualIsSudo;

    if (!actualIsAuthorized && BOT_CONFIG.mode === 'private') {
        await sock.sendMessage(jid, { 
            text: '❌ PRIVATE MODE. SIRF OWNER/SUDO USE KR SAKTA.' 
        }, { quoted: msg });
        return;
    }

    await processCommand(sock, msg, jid, user, command, fullArgs, args, actualIsOwner, actualIsSudo);
}

// ✅ MAIN COMMAND PROCESSOR
async function processCommand(sock, msg, jid, user, command, fullArgs, args, isOwner, isSudo) {
    try {
        const isGroup = jid.endsWith('@g.us');
        
        // ✅ NIL SOUNDS COMMANDS
        if (command.startsWith('nil')) {
            const soundNum = parseInt(command.replace('nil', ''));
            if (!isNaN(soundNum) && soundNum >= 1 && soundNum <= 200) {
                await handleNilSound(sock, msg, jid, soundNum);
                return;
            }
        }
        
        switch(command) {
            case 'ping':
                const start = Date.now();
                await sock.sendMessage(jid, { text: 'Pong!' }, { quoted: msg });
                const latency = Date.now() - start;
                await sock.sendMessage(jid, { 
                    text: `🏓 *PONG!*\n\n• Latency: ${latency}ms\n• Status: Active ✅` 
                }, { quoted: msg });
                break;

            case 'menu':
            case 'help':
                await handleMenu(sock, msg, jid, isOwner);
                break;

            case 'alive':
            case 'info':
                const aliveMsg = `
🤖 *${BOT_CONFIG.name} is ALIVE!*

⚡ Status: Active & Running
🔧 Prefix: ${BOT_CONFIG.prefix}
👤 Owner: ${BOT_CONFIG.owner}
💚 Version: 3.0.0

Type ${BOT_CONFIG.prefix}menu for all commands
                `.trim();
                await sock.sendMessage(jid, { text: aliveMsg }, { quoted: msg });
                break;

            case 'owner':
                await sock.sendMessage(jid, { text: `👤 *Bot Owner:* ${BOT_CONFIG.owner}` }, { quoted: msg });
                break;

            case 'stats':
                const uptime = Date.now() - botData.startTime;
                const stats = `
📊 *BOT STATISTICS*

🤖 Commands Used: ${botData.commandsUsed}
🕒 Uptime: ${formatUptime(uptime)}
🔧 Prefix: ${BOT_CONFIG.prefix}
💚 Status: ${botData.isConnected ? 'Connected' : 'Disconnected'}
✨ Version: 3.0.0
                `.trim();
                await sock.sendMessage(jid, { text: stats }, { quoted: msg });
                break;

            case 'uptime':
            case 'runtime':
                const totalUptime = Math.floor((Date.now() - botData.startTime) / 1000);
                const days = Math.floor(totalUptime / 86400);
                const hrs = Math.floor((totalUptime % 86400) / 3600);
                const mins = Math.floor((totalUptime % 3600) / 60);
                const secs = totalUptime % 60;
                
                await sock.sendMessage(jid, { 
                    text: `⏰ *Uptime:* ${days}d ${hrs}h ${mins}m ${secs}s` 
                }, { quoted: msg });
                break;

            case 'joke':
                const jokes = [
                    "Why don't scientists trust atoms? Because they make up everything!",
                    "Why did the scarecrow win an award? He was outstanding in his field!",
                    "Why don't eggs tell jokes? They'd crack each other up!",
                    "What do you call a fake noodle? An impasta!",
                    "Why did the math book look so sad? Because it had too many problems!"
                ];
                const randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
                await sock.sendMessage(jid, { text: `😂 *Joke:*\n${randomJoke}` }, { quoted: msg });
                break;

            case 'quote':
                const quotes = [
                    "The only way to do great work is to love what you do. - Steve Jobs",
                    "Innovation distinguishes between a leader and a follower. - Steve Jobs",
                    "Your time is limited, so don't waste it living someone else's life. - Steve Jobs",
                    "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt"
                ];
                const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
                await sock.sendMessage(jid, { text: `💫 *Quote:*\n${randomQuote}` }, { quoted: msg });
                break;

            case 'tagall':
                if (!isGroup) {
                    await sock.sendMessage(jid, { text: '❌ This command only works in groups!' }, { quoted: msg });
                    return;
                }
                await handleTagAll(sock, msg, jid, fullArgs);
                break;

            case 'promote':
                if (!isGroup) {
                    await sock.sendMessage(jid, { text: '❌ Group command only!' }, { quoted: msg });
                    return;
                }
                if (!(await isAdmin(sock, jid, user))) {
                    await sock.sendMessage(jid, { text: '❌ Only admins!' }, { quoted: msg });
                    return;
                }
                await handlePromote(sock, msg, jid, args);
                break;

            case 'demote':
                if (!isGroup) {
                    await sock.sendMessage(jid, { text: '❌ Group command only!' }, { quoted: msg });
                    return;
                }
                if (!(await isAdmin(sock, jid, user))) {
                    await sock.sendMessage(jid, { text: '❌ Only admins!' }, { quoted: msg });
                    return;
                }
                await handleDemote(sock, msg, jid, args);
                break;

            case 'kick':
                if (!isGroup) {
                    await sock.sendMessage(jid, { text: '❌ Group command only!' }, { quoted: msg });
                    return;
                }
                if (!(await isAdmin(sock, jid, user))) {
                    await sock.sendMessage(jid, { text: '❌ Only admins!' }, { quoted: msg });
                    return;
                }
                await handleKick(sock, msg, jid, args);
                break;

            case 'kickall':
                if (!isGroup) {
                    await sock.sendMessage(jid, { text: '❌ Group command only!' }, { quoted: msg });
                    return;
                }
                if (!(await isAdmin(sock, jid, user))) {
                    await sock.sendMessage(jid, { text: '❌ Only admins!' }, { quoted: msg });
                    return;
                }
                await handleKickAll(sock, msg, jid);
                break;

            case 'mute':
                if (!isGroup) {
                    await sock.sendMessage(jid, { text: '❌ Group command only!' }, { quoted: msg });
                    return;
                }
                if (!(await isAdmin(sock, jid, user))) {
                    await sock.sendMessage(jid, { text: '❌ Only admins!' }, { quoted: msg });
                    return;
                }
                await handleMute(sock, msg, jid, args);
                break;

            case 'unmute':
                if (!isGroup) {
                    await sock.sendMessage(jid, { text: '❌ Group command only!' }, { quoted: msg });
                    return;
                }
                if (!(await isAdmin(sock, jid, user))) {
                    await sock.sendMessage(jid, { text: '❌ Only admins!' }, { quoted: msg });
                    return;
                }
                await handleUnmute(sock, msg, jid);
                break;

            case 'welcome':
                if (!isGroup) {
                    await sock.sendMessage(jid, { text: '❌ Group command only!' }, { quoted: msg });
                    return;
                }
                if (!(await isAdmin(sock, jid, user))) {
                    await sock.sendMessage(jid, { text: '❌ Only admins!' }, { quoted: msg });
                    return;
                }
                await handleWelcomeToggle(sock, msg, jid, args);
                break;

            case 'goodbye':
                if (!isGroup) {
                    await sock.sendMessage(jid, { text: '❌ Group command only!' }, { quoted: msg });
                    return;
                }
                if (!(await isAdmin(sock, jid, user))) {
                    await sock.sendMessage(jid, { text: '❌ Only admins!' }, { quoted: msg });
                    return;
                }
                await handleGoodbyeToggle(sock, msg, jid, args);
                break;

            case 'antilink':
                if (!isGroup) {
                    await sock.sendMessage(jid, { text: '❌ Group command only!' }, { quoted: msg });
                    return;
                }
                if (!(await isAdmin(sock, jid, user))) {
                    await sock.sendMessage(jid, { text: '❌ Only admins!' }, { quoted: msg });
                    return;
                }
                await handleAntiLink(sock, msg, jid, args);
                break;

            case 'fight':
                if (!isOwner) {
                    await sock.sendMessage(jid, { text: '❌ Only owner!' }, { quoted: msg });
                    return;
                }
                await handleFight(sock, msg, jid, args);
                break;

            case 'sticker':
            case 's':
                await handleSticker(sock, msg, jid);
                break;

            case 'play':
            case 'song':
                if (!fullArgs) {
                    await sock.sendMessage(jid, { 
                        text: '❌ *Usage:* .song song name\n*Example:* .song shape of you' 
                    }, { quoted: msg });
                    return;
                }
                await downloadSong(sock, msg, jid, fullArgs);
                break;

            case 'video':
                if (!fullArgs) {
                    await sock.sendMessage(jid, { 
                        text: '❌ *Usage:* .video video name\n*Example:* .video baby shark' 
                    }, { quoted: msg });
                    return;
                }
                await downloadVideo(sock, msg, jid, fullArgs);
                break;

            case 'yt':
            case 'youtube':
                if (!args[0]) {
                    await sock.sendMessage(jid, { 
                        text: '❌ *Usage:* .yt youtube_url' 
                    }, { quoted: msg });
                    return;
                }
                await handleYouTubeDownload(sock, msg, jid, args[0]);
                break;

            case 'speed':
                await handleSpeedTest(sock, msg, jid);
                break;

            case 'myinfo':
                await handleMyInfo(sock, msg, jid, user);
                break;

            case 'mode':
                if (!isOwner) {
                    await sock.sendMessage(jid, { text: '❌ Only owner!' }, { quoted: msg });
                    return;
                }
                await handleMode(sock, msg, jid, args);
                break;

            case 'addsudo':
                if (!isOwner) {
                    await sock.sendMessage(jid, { text: '❌ Only owner!' }, { quoted: msg });
                    return;
                }
                await handleAddSudo(sock, msg, jid, args);
                break;

            case 'rmsudo':
                if (!isOwner) {
                    await sock.sendMessage(jid, { text: '❌ Only owner!' }, { quoted: msg });
                    return;
                }
                await handleRemoveSudo(sock, msg, jid, args);
                break;

            case 'restart':
                if (!isOwner) {
                    await sock.sendMessage(jid, { text: '❌ Only owner!' }, { quoted: msg });
                    return;
                }
                await handleRestart(sock, msg, jid);
                break;

            case 'report':
                if (!isOwner) {
                    await sock.sendMessage(jid, { text: '❌ Only owner!' }, { quoted: msg });
                    return;
                }
                await handleReport(sock, msg, jid, args);
                break;

            case 'broadcast':
            case 'bc':
                if (!isOwner) {
                    await sock.sendMessage(jid, { text: '❌ Only owner!' }, { quoted: msg });
                    return;
                }
                await handleBroadcast(sock, msg, jid, args.join(' '));
                break;

            default:
                await sock.sendMessage(jid, { 
                    text: `❌ Unknown command: *${command}*\n\nType *${BOT_CONFIG.prefix}menu* for available commands.` 
                }, { quoted: msg });
        }
    } catch (error) {
        console.error('Command error:', error);
        await sock.sendMessage(jid, { 
            text: '❌ Command error.' 
        }, { quoted: msg });
    }
}

// ✅ MENU HANDLER WITH VIDEO
async function handleMenu(sock, msg, jid, isOwner) {
    try {
        // ✅ SEND VIDEO WITH MENU
        const videoUrl = "https://i.imgur.com/9hVHn-QZ_gU.mp4"; // Replace with your video URL
        
        await sock.sendMessage(jid, {
            video: { url: videoUrl },
            caption: `🎬 *${BOT_CONFIG.name} - PREMIUM EDITION*\n\n📞 Owner: +${BOT_CONFIG.owner}\n⚡ Prefix: ${BOT_CONFIG.prefix}\n🔧 Mode: ${BOT_CONFIG.mode.toUpperCase()}`,
            gifPlayback: true
        }, { quoted: msg });

        // ✅ SEND TEXT MENU
        const menuText = `
╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗
║         𝗡𝗜𝗟 𝗕𝗢𝗧 𝗠𝗘𝗡𝗨          ║
║     𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙴𝙳𝙸𝚃𝙸𝙾𝙽 𝚅3        ║
╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗

📞 • 𝐎𝐰𝐧𝐞𝐫: +${BOT_CONFIG.owner}
🤖 • 𝐁𝐨𝐭: +${BOT_CONFIG.botNumber}  
⚡ • 𝐏𝐫𝐞𝐟𝐢𝐱: ${BOT_CONFIG.prefix}
🔧 • 𝐌𝐨𝐝𝐞: ${BOT_CONFIG.mode.toUpperCase()}

╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗
║          𝗚𝗥𝗢𝗨𝗣 𝗖𝗠𝗗𝗦          ║
╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝
┌─・𝙿ʀᴏᴍᴏᴛᴇ @ᴜsᴇʀ » 𝐌ᴀᴋᴇ 𝐀ᴅᴍɪɴ
├─・𝙳ᴇᴍᴏᴛᴇ @ᴜsᴇʀ » 𝐑ᴇᴍᴏᴠᴇ 𝐀ᴅᴍɪɴ
├─・𝙺ɪᴄᴋ @ᴜsᴇʀ » 𝐑ᴇᴍᴏᴠᴇ 𝐔sᴇʀ
├─・𝙺ɪᴄᴋᴀʟʟ » 𝐑ᴇᴍᴏᴠᴇ 𝐀ʟʟ
├─・𝙼ᴜᴛᴇ ᴍɪɴs » 𝐌ᴜᴛᴇ 𝐆ʀᴏᴜᴘ
├─・𝚄ɴᴍᴜᴛᴇ » 𝐔ɴᴍᴜᴛᴇ 𝐆ʀᴏᴜᴘ
├─・𝚃ᴀɢᴀʟʟ ᴍsɢ » 𝐌ᴇɴᴛɪᴏɴ 𝐀ʟʟ
└─・𝙰ɴᴛɪʟɪɴᴋ ᴏɴ/ᴏғғ » 𝐋ɪɴᴋ 𝐏ʀᴏᴛᴇᴄᴛɪᴏɴ

╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗
║         𝗠𝗨𝗦𝗜𝗖 𝗖𝗠𝗗𝗦          ║
╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝
┌─・𝚂ᴏɴɢ ɴᴀᴍᴇ » 𝐘ᴏᴜ𝐓ᴜʙᴇ 𝐌ᴜsɪᴄ
├─・𝚅ɪᴅᴇᴏ ɴᴀᴍᴇ » 𝐘ᴏᴜ𝐓ᴜʙᴇ 𝐕ɪᴅᴇᴏ
├─・𝚈𝚝 𝚞𝚛𝚕 » 𝐃𝐢𝐫𝐞𝐜𝐭 𝐘𝐨𝐮𝐓𝐮𝐛𝐞
└─・𝙽ɪʟ𝟷-𝙽ɪʟ𝟸𝟶𝟶 » 𝐏𝐡𝐨𝐧𝐤 𝐒𝐨𝐮𝐧𝐝𝐬

╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗
║          𝗕𝗢𝗧 𝗖𝗠𝗗𝗦           ║
╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝
┌─・𝙿ɪɴɢ » 𝐂ʜᴇᴄᴋ 𝐒ᴘᴇᴇᴅ
├─・𝚂ᴘᴇᴇᴅ » 𝐒ᴘᴇᴇᴅ 𝐓ᴇsᴛ
├─・𝚂ᴛᴀᴛs » 𝐁ᴏᴛ 𝐒ᴛᴀᴛɪsᴛɪᴄs
├─・𝚁ᴜɴᴛɪᴍᴇ » 𝐑ᴜɴᴛɪᴍᴇ 𝐈ɴғᴏ
├─・𝙾ᴡɴᴇʀ » 𝐎ᴡɴᴇʀ 𝐈ɴғᴏ
├─・𝙼ʏɪɴғᴏ » 𝐘ᴏᴜʀ 𝐈ɴғᴏ
└─・𝙸ɴғᴏ » 𝐁ᴏᴛ 𝐈ɴғᴏ

╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗
║         𝗩𝗢𝗜𝗖𝗘 𝗖𝗠𝗗𝗦          ║
╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝
┌─・𝚅ᴏɪᴄᴇ ᴏɴ/ᴏғғ » 𝐕𝐨𝐢𝐜𝐞 𝐌𝐨𝐝𝐞
├─・𝚅ᴏɪᴄᴇ ʟɪꜱᴛ » 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐋𝐢𝐬𝐭
├─・𝚅ᴏɪᴄᴇ ꜱᴛᴀᴛᴜꜱ » 𝐒𝐭𝐚𝐭𝐮𝐬
└─・𝙷ɪ/𝙷𝚎𝚕𝚕𝚘 » 𝐀𝐮𝐭𝐨 𝐕𝐨𝐢𝐜𝐞

🎪 • 𝐍𝐈𝐋 𝐁𝐎𝐓 - 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝐄𝐃𝐈𝐓𝐈𝐎𝐍
`.trim();

        await sock.sendMessage(jid, { text: menuText }, { quoted: msg });

    } catch (error) {
        console.error('Menu error:', error);
        // Fallback to text only menu
        const fallbackMenu = `
🤖 *${BOT_CONFIG.name} - PREMIUM MENU*

📞 Owner: +${BOT_CONFIG.owner}
⚡ Prefix: ${BOT_CONFIG.prefix}
🔧 Mode: ${BOT_CONFIG.mode.toUpperCase()}

*Group Commands:*
• .promote @user
• .demote @user  
• .kick @user
• .mute minutes
• .tagall message
• .antilink on/off

*Music Commands:*
• .song name
• .video name
• .yt url
• .nil1-nil200

*Voice Commands:*
• .voice on/off
• .voice list
• .voice status

*Bot Commands:*
• .ping • .stats • .owner
• .menu • .alive • .myinfo
        `.trim();
        await sock.sendMessage(jid, { text: fallbackMenu }, { quoted: msg });
    }
}

// ✅ OTHER COMMAND HANDLERS (TagAll, Promote, Demote, etc.)
async function handleTagAll(sock, msg, jid, message = '') {
    try {
        const groupMetadata = await sock.groupMetadata(jid);
        const participants = groupMetadata.participants;
        
        let tagMessage = message || '🚀 Attention!';
        let mentions = [];
        
        participants.forEach(participant => {
            mentions.push(participant.id);
        });

        await sock.sendMessage(jid, { 
            text: `${tagMessage}\n\n${mentions.map((_, i) => `@${participants[i].id.split('@')[0]}`).join(' ')}`,
            mentions: mentions
        }, { quoted: msg });

    } catch (error) {
        await sock.sendMessage(jid, { text: '❌ Tagall failed!' }, { quoted: msg });
    }
}

async function handlePromote(sock, msg, jid, args) {
    try {
        const quoted = msg.message?.extendedTextMessage?.contextInfo;
        let targetUser = args[0];
        
        if (quoted?.participant) {
            targetUser = quoted.participant;
        } else if (targetUser && targetUser.startsWith('@')) {
            targetUser = targetUser.slice(1) + '@s.whatsapp.net';
        } else {
            await sock.sendMessage(jid, { text: '❌ Reply to user or use: .promote @user' }, { quoted: msg });
            return;
        }

        await sock.groupParticipantsUpdate(jid, [targetUser], 'promote');
        await sock.sendMessage(jid, { text: '✅ User promoted to admin!' }, { quoted: msg });
        
    } catch (error) {
        await sock.sendMessage(jid, { text: '❌ Promote failed!' }, { quoted: msg });
    }
}

async function handleDemote(sock, msg, jid, args) {
    try {
        const quoted = msg.message?.extendedTextMessage?.contextInfo;
        let targetUser = args[0];
        
        if (quoted?.participant) {
            targetUser = quoted.participant;
        } else if (targetUser && targetUser.startsWith('@')) {
            targetUser = targetUser.slice(1) + '@s.whatsapp.net';
        } else {
            await sock.sendMessage(jid, { text: '❌ Reply to user or use: .demote @user' }, { quoted: msg });
            return;
        }

        await sock.groupParticipantsUpdate(jid, [targetUser], 'demote');
        await sock.sendMessage(jid, { text: '✅ User demoted from admin!' }, { quoted: msg });
        
    } catch (error) {
        await sock.sendMessage(jid, { text: '❌ Demote failed!' }, { quoted: msg });
    }
}

async function handleKick(sock, msg, jid, args) {
    try {
        const quoted = msg.message?.extendedTextMessage?.contextInfo;
        let targetUser = args[0];
        
        if (quoted?.participant) {
            targetUser = quoted.participant;
        } else if (targetUser && targetUser.startsWith('@')) {
            const mentionedNumber = targetUser.slice(1);
            targetUser = mentionedNumber + '@s.whatsapp.net';
        } else if (targetUser && targetUser.match(/^\d+$/)) {
            targetUser = targetUser + '@s.whatsapp.net';
        } else if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
            targetUser = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else {
            await sock.sendMessage(jid, { 
                text: '❌ *Usage:*\n• .kick @user\n• .kick number\n• Reply .kick to user message' 
            }, { quoted: msg });
            return;
        }

        const groupMetadata = await sock.groupMetadata(jid);
        const participants = groupMetadata.participants;
        const userExists = participants.find(p => p.id === targetUser);
        
        if (!userExists) {
            await sock.sendMessage(jid, { text: '❌ User group mein nahi hai!' }, { quoted: msg });
            return;
        }

        const botAdmin = participants.find(p => p.id === sock.user.id);
        if (!botAdmin || !botAdmin.admin) {
            await sock.sendMessage(jid, { text: '❌ Mujhe admin banao pehle!' }, { quoted: msg });
            return;
        }

        await sock.groupParticipantsUpdate(jid, [targetUser], 'remove');
        
        const userNumber = targetUser.split('@')[0];
        await sock.sendMessage(jid, { 
            text: `✅ @${userNumber} ko group se nikal diya!`,
            mentions: [targetUser]
        }, { quoted: msg });
        
    } catch (error) {
        console.error('Kick error:', error);
        await sock.sendMessage(jid, { text: '❌ Kick fail! Bot admin nahi hai.' }, { quoted: msg });
    }
}

async function handleKickAll(sock, msg, jid) {
    try {
        await sock.sendMessage(jid, { text: '🔄 Removing all members...' }, { quoted: msg });
        
        const groupMetadata = await sock.groupMetadata(jid);
        const participants = groupMetadata.participants;
        
        const usersToRemove = participants.filter(p => 
            !p.admin && 
            !p.id.includes(BOT_CONFIG.botNumber) &&
            !p.id.includes(BOT_CONFIG.owner)
        );
        
        if (usersToRemove.length === 0) {
            await sock.sendMessage(jid, { text: '❌ No members to remove!' }, { quoted: msg });
            return;
        }
        
        const userIDs = usersToRemove.map(p => p.id);
        
        for (let i = 0; i < userIDs.length; i += 5) {
            const batch = userIDs.slice(i, i + 5);
            await sock.groupParticipantsUpdate(jid, batch, 'remove');
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
        
        await sock.sendMessage(jid, { 
            text: `✅ Removed ${userIDs.length} members from group!` 
        }, { quoted: msg });
        
    } catch (error) {
        console.error('Kickall error:', error);
        await sock.sendMessage(jid, { text: '❌ Kickall failed! Make sure I am admin.' }, { quoted: msg });
    }
}

async function handleMute(sock, msg, jid, args) {
    try {
        const duration = args[0] ? parseInt(args[0]) : null;
        
        if (duration && (duration < 1 || duration > 1440)) {
            await sock.sendMessage(jid, { 
                text: '❌ Use 1-1440 minutes.' 
            }, { quoted: msg });
            return;
        }

        await sock.groupSettingUpdate(jid, 'announcement');
        
        const groupSettings = initGroupSettings(jid);
        groupSettings.muted = true;
        groupSettings.muteDuration = duration;

        let response = `✅ Muted ${duration ? `${duration} minutes` : 'forever'}!`;
        if (duration) {
            setTimeout(() => handleUnmute(sock, null, jid), duration * 60 * 1000);
        }

        await sock.sendMessage(jid, { text: response }, { quoted: msg });

    } catch (error) {
        await sock.sendMessage(jid, { text: '❌ Mute failed!' }, { quoted: msg });
    }
}

async function handleUnmute(sock, msg, jid) {
    try {
        await sock.groupSettingUpdate(jid, 'not_announcement');
        
        const groupSettings = initGroupSettings(jid);
        groupSettings.muted = false;
        groupSettings.muteDuration = null;

        if (msg) {
            await sock.sendMessage(jid, { text: '🔊 Unmuted!' }, { quoted: msg });
        }
    } catch (error) {
        if (msg) {
            await sock.sendMessage(jid, { text: '❌ Unmute failed!' }, { quoted: msg });
        }
    }
}

async function handleWelcomeToggle(sock, msg, jid, args) {
    try {
        const groupSettings = initGroupSettings(jid);
        const action = args[0]?.toLowerCase();

        if (action === 'on') {
            groupSettings.welcome = true;
            await sock.sendMessage(jid, { 
                text: '✅ *WELCOME MESSAGE ON!*\n\n🎊 Ab naye members join karne par welcome message bheja jayega.' 
            }, { quoted: msg });
        } else if (action === 'off') {
            groupSettings.welcome = false;
            await sock.sendMessage(jid, { 
                text: '❌ *WELCOME MESSAGE OFF!*\n\n🔇 Ab naye members join karne par koi message nahi bheja jayega.' 
            }, { quoted: msg });
        } else {
            const status = groupSettings.welcome ? 'ON ✅' : 'OFF ❌';
            await sock.sendMessage(jid, { 
                text: `🎊 *WELCOME SETTINGS*\n\n• Status: ${status}\n• Group: ${jid}\n\nUse: .welcome on/off` 
            }, { quoted: msg });
        }
    } catch (error) {
        console.error('Welcome toggle error:', error);
        await sock.sendMessage(jid, { 
            text: '❌ Welcome settings change karne mein error!' 
        }, { quoted: msg });
    }
}

async function handleGoodbyeToggle(sock, msg, jid, args) {
    try {
        const groupSettings = initGroupSettings(jid);
        const action = args[0]?.toLowerCase();

        if (action === 'on') {
            groupSettings.goodbye = true;
            await sock.sendMessage(jid, { 
                text: '✅ *GOODBYE MESSAGE ON!*\n\n🚪 Ab members leave karne par goodbye message bheja jayega.' 
            }, { quoted: msg });
        } else if (action === 'off') {
            groupSettings.goodbye = false;
            await sock.sendMessage(jid, { 
                text: '❌ *GOODBYE MESSAGE OFF!*\n\n🔇 Ab members leave karne par koi message nahi bheja jayega.' 
            }, { quoted: msg });
        } else {
            const status = groupSettings.goodbye ? 'ON ✅' : 'OFF ❌';
            await sock.sendMessage(jid, { 
                text: `🚪 *GOODBYE SETTINGS*\n\n• Status: ${status}\n• Group: ${jid}\n\nUse: .goodbye on/off` 
            }, { quoted: msg });
        }
    } catch (error) {
        console.error('Goodbye toggle error:', error);
        await sock.sendMessage(jid, { 
            text: '❌ Goodbye settings change karne mein error!' 
        }, { quoted: msg });
    }
}

async function handleAntiLink(sock, msg, jid, args) {
    const groupSettings = initGroupSettings(jid);
    const action = args[0]?.toLowerCase();

    switch(action) {
        case 'on':
            groupSettings.antiLink = true;
            groupSettings.warnSystem = true;
            groupSettings.kickOnLink = true;
            
            await sock.sendMessage(jid, { 
                text: `╔══════════════════════════╗
║     🛡️ 4ɴᴛ1-ʟ1ɴᴋ ᴏɴ     ║
╚══════════════════════════╝

✅ ᴘʀᴏᴛ3ᴄᴛ1ᴏɴ 4ᴄᴛ1ᴠ4ᴛ3ᴅ!
┌─ ʟ1ɴᴋ ᴅ3ʟ3ᴛ3 ➔ ✅
├─ ᴡ4ʀɴ ꜱʏꜱᴛ3ᴍ ➔ ✅  
└─ 4ᴜᴛᴏ-ᴋ1ᴄᴋ ➔ ✅` 
            }, { quoted: msg });
            break;
            
        case 'off':
            groupSettings.antiLink = false;
            groupSettings.warnSystem = false;
            await sock.sendMessage(jid, { 
                text: `╔══════════════════════════╗
║    ❌ 4ɴᴛ1-ʟ1ɴᴋ ᴏꜰꜰ    ║
╚══════════════════════════╝

🔓 ᴘʀᴏᴛ3ᴄᴛ1ᴏɴ ᴅ1ꜱ4ʙʟ3ᴅ!
┌─ ʟ1ɴᴋ ᴅ3ʟ3ᴛ3 ➔ ❌
├─ ᴡ4ʀɴ ꜱʏꜱᴛ3ᴍ ➔ ❌
└─ 4ᴜᴛᴏ-ᴋ1ᴄᴋ ➔ ❌` 
            }, { quoted: msg });
            break;
            
        default:
            const status = groupSettings.antiLink ? 'ON ✅' : 'OFF ❌';
            const deleteStatus = groupSettings.deleteLink ? 'ON ✅' : 'OFF ❌';
            const kickStatus = groupSettings.kickOnLink ? 'ON ✅' : 'OFF ❌';
            const warnStatus = groupSettings.warnSystem ? 'ON ✅' : 'OFF ❌';
            
            await sock.sendMessage(jid, { 
                text: `╔══════════════════════════════╗
║       🛡️ 4ɴᴛ1-ʟ1ɴᴋ ꜱᴛ4ᴛꜱ       ║
╚══════════════════════════════╝

┌─ ᴘʀᴏᴛ3ᴄᴛ1ᴏɴ: ${status}
├─ ʟ1ɴᴋ ᴅ3ʟ3ᴛ3: ${deleteStatus}
├─ 4ᴜᴛᴏ-ᴋ1ᴄᴋ: ${kickStatus}
└─ ᴡ4ʀɴ ꜱʏꜱᴛ3ᴍ: ${warnStatus}

Use: .antilink on/off` 
            }, { quoted: msg });
    }
}

async function handleFight(sock, msg, jid, args) {
    const user = msg.key.participant || jid;
    const action = args[0]?.toLowerCase();
    
    const userWhatsappNumber = user.replace('@s.whatsapp.net', '');
    const ownerWhatsappNumber = BOT_CONFIG.owner;
    
    const isOwner = userWhatsappNumber === ownerWhatsappNumber;
    
    if (!isOwner) {
        await sock.sendMessage(jid, { 
            text: `❌ *OWNER ONLY COMMAND!*\n\n👑 Owner: ${BOT_CONFIG.ownerName} (+${BOT_CONFIG.owner})` 
        }, { quoted: msg });
        return;
    }

    if (action === 'on') {
        botData.fightMode.set('global', true);
        await sock.sendMessage(jid, { 
            text: `🥊 *GLOBAL FIGHT MODE ON!*\n\n✅ Activated by: ${BOT_CONFIG.ownerName}` 
        }, { quoted: msg });
    } else if (action === 'off') {
        botData.fightMode.delete('global');
        await sock.sendMessage(jid, { 
            text: `🕊️ *GLOBAL FIGHT MODE OFF!*\n\n❌ Deactivated by: ${BOT_CONFIG.ownerName}` 
        }, { quoted: msg });
    } else {
        const status = botData.fightMode.has('global') ? 'ON 🥊' : 'OFF 🕊️';
        await sock.sendMessage(jid, { 
            text: `🥊 *GLOBAL FIGHT MODE*\n\n• Status: ${status}\n• Owner: ${BOT_CONFIG.ownerName}\n\nUse: .fight on/off` 
        }, { quoted: msg });
    }
}

async function handleSticker(sock, msg, jid) {
    try {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        
        if (!quoted && !msg.message?.imageMessage) {
            await sock.sendMessage(jid, { 
                text: '❌ Reply to image/video!' 
            }, { quoted: msg });
            return;
        }

        await sock.sendMessage(jid, { text: '🔄 Creating sticker...' }, { quoted: msg });

        let buffer;
        if (quoted?.imageMessage || quoted?.videoMessage) {
            const stream = await downloadMediaFromMessage(quoted);
            buffer = await streamToBuffer(stream);
        } else if (msg.message?.imageMessage) {
            const stream = await downloadMediaFromMessage(msg.message);
            buffer = await streamToBuffer(stream);
        }

        if (buffer) {
            await sock.sendMessage(jid, { sticker: buffer }, { quoted: msg });
        }
    } catch (error) {
        console.error('Sticker error:', error);
        await sock.sendMessage(jid, { text: '❌ Sticker failed!' }, { quoted: msg });
    }
}

async function downloadSong(sock, msg, jid, query) {
    try {
        await sock.sendMessage(jid, { 
            text: `🎵 *Searching:* "${query}"\n\n⏳ *Downloading audio...*` 
        }, { quoted: msg });

        const searchResult = await yts(query);
        if (!searchResult.videos.length) {
            await sock.sendMessage(jid, { text: '❌ *No songs found!*' }, { quoted: msg });
            return;
        }

        const video = searchResult.videos[0];
        const videoUrl = video.url;

        if (!fs.existsSync('./temp')) {
            fs.mkdirSync('./temp');
        }

        const filename = `song_${Date.now()}.mp3`;
        const filepath = `./temp/${filename}`;

        console.log(`📥 Downloading: ${video.title}`);

        return new Promise((resolve, reject) => {
            const audioStream = ytdl(videoUrl, {
                filter: 'audioonly',
                quality: 'highestaudio'
            });

            const writeStream = fs.createWriteStream(filepath);
            
            audioStream.pipe(writeStream);

            writeStream.on('finish', async () => {
                try {
                    console.log(`✅ Downloaded: ${filename}`);
                    
                    await sock.sendMessage(jid, {
                        audio: fs.readFileSync(filepath),
                        mimetype: 'audio/mpeg',
                        fileName: `${video.title.substring(0, 30)}.mp3`.replace(/[^\w\s.-]/gi, '')
                    }, { quoted: msg });

                    fs.unlinkSync(filepath);
                    console.log(`✅ Audio sent successfully`);
                    resolve();
                    
                } catch (sendError) {
                    console.error('Send error:', sendError);
                    await sock.sendMessage(jid, { 
                        text: `🎵 *${video.title}*\n\n🔗 *YouTube Link:* ${videoUrl}` 
                    }, { quoted: msg });
                    reject(sendError);
                }
            });

            writeStream.on('error', async (error) => {
                console.error('Download error:', error);
                await sock.sendMessage(jid, { 
                    text: '❌ *Download failed!*' 
                }, { quoted: msg });
                reject(error);
            });
        });

    } catch (error) {
        console.error('Song error:', error);
        await sock.sendMessage(jid, { 
            text: '❌ *Song search failed!*' 
        }, { quoted: msg });
    }
}

async function downloadVideo(sock, msg, jid, query) {
    try {
        await sock.sendMessage(jid, { 
            text: `🎥 *Searching:* "${query}"\n\n⏳ *Downloading video...*` 
        }, { quoted: msg });

        const searchResult = await yts(query);
        if (!searchResult.videos.length) {
            await sock.sendMessage(jid, { text: '❌ *No videos found!*' }, { quoted: msg });
            return;
        }

        const video = searchResult.videos[0];
        const videoUrl = video.url;

        if (!fs.existsSync('./temp')) {
            fs.mkdirSync('./temp');
        }

        const filename = `video_${Date.now()}.mp4`;
        const filepath = `./temp/${filename}`;

        console.log(`📥 Downloading: ${video.title}`);

        return new Promise((resolve, reject) => {
            const videoStream = ytdl(videoUrl, {
                filter: 'audioandvideo',
                quality: 'lowest'
            });

            const writeStream = fs.createWriteStream(filepath);
            
            videoStream.pipe(writeStream);

            writeStream.on('finish', async () => {
                try {
                    console.log(`✅ Downloaded: ${filename}`);
                    
                    await sock.sendMessage(jid, {
                        video: fs.readFileSync(filepath),
                        mimetype: 'video/mp4',
                        caption: `🎥 *${video.title}*`
                    }, { quoted: msg });

                    fs.unlinkSync(filepath);
                    console.log(`✅ Video sent successfully`);
                    resolve();
                    
                } catch (sendError) {
                    console.error('Send error:', sendError);
                    await sock.sendMessage(jid, { 
                        text: `🎥 *${video.title}*\n\n🔗 *YouTube Link:* ${videoUrl}` 
                    }, { quoted: msg });
                    reject(sendError);
                }
            });

            writeStream.on('error', async (error) => {
                console.error('Download error:', error);
                await sock.sendMessage(jid, { 
                    text: '❌ *Download failed!*' 
                }, { quoted: msg });
                reject(error);
            });
        });

    } catch (error) {
        console.error('Video error:', error);
        await sock.sendMessage(jid, { 
            text: '❌ *Video search failed!*' 
        }, { quoted: msg });
    }
}

async function handleYouTubeDownload(sock, msg, jid, url) {
    try {
        if (!url) {
            await sock.sendMessage(jid, { 
                text: '❌ *Usage:* .yt youtube_url' 
            }, { quoted: msg });
            return;
        }

        await sock.sendMessage(jid, { 
            text: '🎥 *YouTube Download Started...*\n\n⏳ Please wait, downloading video...' 
        }, { quoted: msg });

        const info = await ytdl.getInfo(url);
        const video = info.videoDetails;
        const title = video.title;
        
        if (!fs.existsSync('./temp')) {
            fs.mkdirSync('./temp');
        }

        const filename = `youtube_${Date.now()}.mp4`;
        const filepath = `./temp/${filename}`;

        const videoStream = ytdl(url, {
            quality: 'lowest',
            filter: 'audioandvideo'
        });

        const writeStream = fs.createWriteStream(filepath);
        videoStream.pipe(writeStream);

        writeStream.on('finish', async () => {
            try {
                await sock.sendMessage(jid, {
                    video: fs.readFileSync(filepath),
                    mimetype: 'video/mp4',
                    caption: `🎥 *${title}*\n✅ Downloaded via NIL BOT`
                }, { quoted: msg });
                
                fs.unlinkSync(filepath);
            } catch (error) {
                await sock.sendMessage(jid, { 
                    text: `❌ Video send failed! But here's the link:\n${url}` 
                }, { quoted: msg });
            }
        });

        writeStream.on('error', async (error) => {
            await sock.sendMessage(jid, { 
                text: '❌ YouTube download failed! Invalid URL or video.' 
            }, { quoted: msg });
        });

    } catch (error) {
        console.error('YouTube error:', error);
        await sock.sendMessage(jid, { 
            text: '❌ YouTube download error! Please check the URL.' 
        }, { quoted: msg });
    }
}

async function handleSpeedTest(sock, msg, jid) {
    const startTime = Date.now();
    await sock.sendMessage(jid, { text: '🚀 Testing...' }, { quoted: msg });
    const endTime = Date.now();
    
    const ping = endTime - startTime;
    await sock.sendMessage(jid, { 
        text: `📊 *SPEED*\n\n• Ping: ${ping}ms\n• Commands: ${botData.commandsUsed}\n• Uptime: ${formatUptime(Date.now() - botData.startTime)}` 
    }, { quoted: msg });
}

async function handleMyInfo(sock, msg, jid, user) {
    const isOwner = isUserOwner(user);
    const isSudo = botData.sudos.some(sudo => isUserOwner(sudo));
    const userNumber = user.split('@')[0];
    
    const userInfo = `
📱 *YOUR INFORMATION*

• Your Number: ${userNumber}
• Status: ${isOwner ? '👑 OWNER' : isSudo ? '⚡ SUDO USER' : '👤 REGULAR USER'}
• Bot Mode: ${BOT_CONFIG.mode.toUpperCase()}
• Fight Mode: ${botData.fightMode.has('global') ? 'ON 🥊' : 'OFF 🕊️'}

👑 *OWNER DETAILS*
• Name: ${BOT_CONFIG.ownerName}
• Number: +${BOT_CONFIG.owner}
    `.trim();

    await sock.sendMessage(jid, { text: userInfo }, { quoted: msg });
}

async function handleMode(sock, msg, jid, args) {
    const mode = args[0]?.toLowerCase();
    
    if (mode === 'public') {
        BOT_CONFIG.mode = 'public';
        await sock.sendMessage(jid, { text: '✅ Mode changed to PUBLIC!' }, { quoted: msg });
    } else if (mode === 'private') {
        BOT_CONFIG.mode = 'private';
        await sock.sendMessage(jid, { text: '✅ Mode changed to PRIVATE!' }, { quoted: msg });
    } else {
        await sock.sendMessage(jid, { 
            text: `🔒 *MODE SETTINGS*\n\nCurrent: ${BOT_CONFIG.mode.toUpperCase()}\n\nUse: .mode public/private` 
        }, { quoted: msg });
    }
}

async function handleAddSudo(sock, msg, jid, args) {
    if (!args[0]) {
        await sock.sendMessage(jid, { text: '❌ Use: .addsudo number' }, { quoted: msg });
        return;
    }

    const sudoNumber = args[0].replace(/[^0-9]/g, '');
    if (!sudoNumber) {
        await sock.sendMessage(jid, { text: '❌ Invalid number!' }, { quoted: msg });
        return;
    }

    const sudoJid = `${sudoNumber}@s.whatsapp.net`;
    
    if (botData.sudos.includes(sudoJid)) {
        await sock.sendMessage(jid, { text: '❌ Already sudo!' }, { quoted: msg });
        return;
    }

    botData.sudos.push(sudoJid);
    await sock.sendMessage(jid, { text: `✅ Added ${sudoNumber} as sudo!` }, { quoted: msg });
}

async function handleRemoveSudo(sock, msg, jid, args) {
    if (!args[0]) {
        await sock.sendMessage(jid, { text: '❌ Use: .rmsudo number' }, { quoted: msg });
        return;
    }

    const sudoNumber = args[0].replace(/[^0-9]/g, '');
    const sudoJid = `${sudoNumber}@s.whatsapp.net`;
    
    const index = botData.sudos.indexOf(sudoJid);
    if (index === -1) {
        await sock.sendMessage(jid, { text: '❌ Not a sudo!' }, { quoted: msg });
        return;
    }

    botData.sudos.splice(index, 1);
    await sock.sendMessage(jid, { text: `✅ Removed ${sudoNumber} from sudo!` }, { quoted: msg });
}

async function handleRestart(sock, msg, jid) {
    await sock.sendMessage(jid, { text: '🔄 Restarting bot...' }, { quoted: msg });
    setTimeout(() => {
        process.exit(0);
    }, 2000);
}

async function handleReport(sock, msg, jid, args) {
    try {
        if (args.length < 1) {
            await sock.sendMessage(jid, { 
                text: '❌ *USAGE:* .report +923474810818' 
            }, { quoted: msg });
            return;
        }

        let targetNumber = args[0];
        targetNumber = targetNumber.replace(/[^0-9+]/g, '');
        
        await sock.sendMessage(jid, { 
            text: `🚨 *REPORT SYSTEM*\n\n📱 Target: ${targetNumber}\n🔧 Report system activated!\n\n⚠️ This is a demo version.` 
        }, { quoted: msg });

    } catch (error) {
        console.error('Report system error:', error);
        await sock.sendMessage(jid, { 
            text: '❌ Report system error!' 
        }, { quoted: msg });
    }
}

async function handleBroadcast(sock, msg, jid, message) {
    if (!message) {
        await sock.sendMessage(jid, { text: '❌ Usage: .bc message' }, { quoted: msg });
        return;
    }

    await sock.sendMessage(jid, { text: '📢 Starting broadcast...' }, { quoted: msg });
    await sock.sendMessage(jid, { text: '✅ Broadcast completed!' }, { quoted: msg });
}

async function handleNilSound(sock, msg, jid, soundNumber) {
    try {
        const phonkSongs = {
            1: "https://youtu.be/9hVHn-QZ_gU",
            2: "https://youtu.be/Dx5qZh-cksU",
            3: "https://youtu.be/gWOeY6n6o8M",
            4: "https://youtu.be/7a9s9hqdDgE",
            5: "https://youtu.be/6CTurbfZkC8",
            50: "https://youtu.be/5qap5aO4i9A",
            100: "https://youtu.be/jfKfPfyJRdk",
            150: "https://youtu.be/4xDzrJKXOOY",
            200: "https://youtu.be/L_jWHffIx5E"
        };

        const soundTypes = [
            "🔥 Phonk", "🚗 Drift Phonk", "🇷🇺 Russian Phonk", "🇧🇷 Brazilian Phonk", 
            "🌙 Dark Phonk", "💢 Aggressive Phonk", "🔊 Bass Boosted"
        ];

        const soundType = soundTypes[soundNumber % soundTypes.length];
        
        let songUrl;
        if (phonkSongs[soundNumber]) {
            songUrl = phonkSongs[soundNumber];
        } else {
            const availableNumbers = Object.keys(phonkSongs).map(Number);
            songUrl = phonkSongs[availableNumbers[soundNumber % availableNumbers.length]];
        }

        await sock.sendMessage(jid, { 
            text: `🎵 *NIL${soundNumber} - ${soundType}*\n\n🔗 Downloading: ${songUrl}\n\n⏳ Please wait...` 
        }, { quoted: msg });

    } catch (error) {
        console.error('Nil sound error:', error);
        await sock.sendMessage(jid, { 
            text: `❌ NIL${soundNumber} failed! Try another number.` 
        }, { quoted: msg });
    }
}

// ✅ ERROR HANDLERS
process.on('uncaughtException', (error) => {
    console.error('❌ Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
});

// ✅ START THE BOT
console.log('='.repeat(60));
console.log('🚀 ULTIMATE NIL BOT - DUAL DEPLOYMENT VERSION');
console.log('📞 Owner: ' + BOT_CONFIG.owner);
console.log('⚡ Prefix: ' + BOT_CONFIG.prefix);
console.log('🔧 Mode: ' + BOT_CONFIG.mode.toUpperCase());
console.log('='.repeat(60));

// ✅ START DEPLOYMENT SELECTOR
selectDeploymentMethod();

// ✅ Handle Ctrl+C gracefully
process.on('SIGINT', () => {
    console.log('\n\n👋 Bot stopped by user');
    rl.close();
    process.exit(0);
});

module.exports = {
    BOT_CONFIG,
    botData,
    startBot
};































